cd /app/adminpic/
rm *.jpg