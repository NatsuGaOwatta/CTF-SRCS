default_app_config = 'xremote.apps.XRemoteConfig'
