<?php 
libxml_disable_entity_loader(true);