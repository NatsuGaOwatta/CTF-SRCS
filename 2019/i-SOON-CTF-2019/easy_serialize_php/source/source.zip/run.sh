#! /usr/bin/env bash
service apache2 start
/bin/bash


