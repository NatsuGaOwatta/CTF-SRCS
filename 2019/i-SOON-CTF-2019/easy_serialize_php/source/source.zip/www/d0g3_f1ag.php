<?php

$flag = 'flag in /d0g3_fllllllag';

?>