#!/bin/bash
docker build -t eboda/l33t-hoster .
