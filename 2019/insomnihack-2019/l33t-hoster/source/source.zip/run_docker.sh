#!/bin/sh
#docker run -p 127.0.0.1:8000:80 -it eboda/l33t-hoster
docker run -p 8000:80 -it eboda/l33t-hoster
