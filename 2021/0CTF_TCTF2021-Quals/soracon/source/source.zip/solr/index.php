<?php header('HTTP/1.0 200 OK');?>
<?='<?xml version="1.0" encoding="UTF-8"?>'?>
<response>
<result name="response" numFound="1" start="0" numFoundExact="true">
  <doc name="fuck">
    <int name="a">123456</int>
    <int name="b">12345678</int>
  </doc>
</result>
</response>

