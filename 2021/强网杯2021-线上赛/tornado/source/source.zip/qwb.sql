﻿# Host: localhost  (Version: 5.7.26)
# Date: 2021-05-31 09:15:27
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "users"
#

create database qwb;
use qwb;

DROP TABLE IF EXISTS `qwbtttaaab111e`;
CREATE TABLE `qwbtttaaab111e` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qwbqwbqwbuser` varchar(255) DEFAULT NULL,
  `qwbqwbqwbpass` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# Data for table "qwbtttaaab111e"
#

/*!40000 ALTER TABLE `qwbtttaaab111e` DISABLE KEYS */;
INSERT INTO `qwbtttaaab111e` VALUES (1,'admin','we111c000me_to_qwb');
/*!40000 ALTER TABLE `qwbtttaaab111e` ENABLE KEYS */;
